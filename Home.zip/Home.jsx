import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="relative overflow-hidden bg-white mb-3">
      {/* Hero Section */}
      <div className="pb-80 pt-16 sm:pb-40 sm:pt-24 lg:pb-48 lg:pt-40 ">
        <div className="relative mx-auto max-w-7xl px-4 sm:static sm:px-6 lg:px-8">
          <div className="sm:max-w-lg">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
              New
              <span className="text-orange-600 p-4">
                <span className="text-[6rem]">S</span>eason.
              </span>
              <br />
              New
              <span className="text-orange-600 p-4">
                <span className="text-[4.2rem]">M</span>ood.
              </span>
              <br />
              New
              <span className="text-orange-600 p-4">You.</span>
            </h1>
            <p className="mt-4 flex text-xl text-gray-500">
              It's Time To Turn Over A New Leaf🌿
            </p>
            <Link
              to="/product"
              className="inline-block rounded-md border border-transparent bg-orange-600 px-8 py-3 text-center font-medium text-white hover:bg-orange-700 mt-4"
            >
              Explore Now 🌿
            </Link>
          </div>

          {/* Images Right Side */}
          <div className="mt-10">
            <div className="sm:absolute transform sm:left-1/2 sm:top-0 sm:translate-x-8 lg:left-1/2 lg:top-1/2 lg:-translate-y-1/2 lg:translate-x-8">
              <div className="flex items-center space-x-6 lg:space-x-8">
                {/* Images columns (same as before) */}
                {/* ...keep all your image blocks here... */}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 🌟 Featured Products Section */}
      <section className="bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            🌟 Featured Products
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {[
              {
                id: 1,
                name: "Wireless Headphones",
                price: 2999,
                image:
                  "https://via.placeholder.com/300x300.png?text=Headphones",
              },
              {
                id: 2,
                name: "Smartwatch",
                price: 4999,
                image:
                  "https://via.placeholder.com/300x300.png?text=Smartwatch",
              },
              {
                id: 3,
                name: "Stylish Backpack",
                price: 1999,
                image:
                  "https://via.placeholder.com/300x300.png?text=Backpack",
              },
              {
                id: 4,
                name: "Running Shoes",
                price: 3999,
                image:
                  "https://via.placeholder.com/300x300.png?text=Shoes",
              },
            ].map((product) => (
              <div
                key={product.id}
                className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-60 object-cover rounded-t-lg"
                />
                <div className="p-4">
                  <h3 className="text-lg font-semibold text-gray-800">
                    {product.name}
                  </h3>
                  <p className="text-orange-600 font-bold mt-1">₹{product.price}</p>
                  <Link
                    to="/product"
                    className="inline-block mt-3 px-4 py-2 text-sm bg-orange-500 text-white rounded hover:bg-orange-600"
                  >
                    View Product
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
